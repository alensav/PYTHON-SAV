<?php
// Copyright (c) 2006-2011 Igor Anikeev http://www.arwshop.ru/ 

 // Если файл загружен не из движка - завершаем программу
 if(! defined('SYS_LOADER')){
 die();
 }

$pmmod_conf = array();
$pmmod_conf['pmmod_title'] = 'Пример платежного модуля' ;

?>