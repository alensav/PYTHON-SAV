<?php
 // Если файл загружен не из движка - завершаем программу
 if(! defined('SYS_LOADER')){
 die();
 }
?>
<h1>Пример платежного модуля в общедоступной части</h1>
<?php

//получаем номер заказа после оформления заказа
$order_id = get_order_id();

 //если есть номер заказа выводим форму оплаты
 if($order_id > 0){
 print payment_form($order_id);
 }



function payment_form($order_id){
//получаем данные заказа
$order_data = get_order_data($order_id);

//возвращаем форму
return <<<HTMLDATA
<form action="https://www.example.com/adress" method="POST" style="margin:3px;">
<h4>Оплата через платежную систему &quot;Example...&quot;</h4>
<input type="hidden" name="order_number" value="{$order_data['order']['orderid']}">
<input type="hidden" name="amount" value="{$order_data['order']['final_total_pc']}">
<p>Сумма платежа {$order_data['order']['final_total_pc']} {$order_data['order']['currency_brief']}</p>
<input type="submit" value="Перейти к оплате"><br>
</form>
HTMLDATA;
}



/**********************************Пример POST и GET форм...**********************************/



?>
<br><hr>
<h3>Пример POST и GET форм...</h3>
<?php
  if(! empty($_POST['sample_text'])){
  echo '<hr>Данные переданные методом &quot;POST&quot;: <span style="color:#0000FF;">'.strip_tags($_POST['sample_text']).'</span><hr>';
  }
  elseif(! empty($_GET['sample_text'])){
  echo '<hr>Данные переданные методом &quot;GET&quot;: <span style="color:#0000FF;">'.strip_tags($_GET['sample_text']).'</span><hr>';
  }

?>
<form name="sample_form" action="?" method="POST">
<input type="hidden" name="pmmod" value="sample">
<input type="hidden" name="independ" value="<?php if(! empty($_GET['independ']) || ! empty($_POST['independ'])){echo '1';} ?>">
<input type="test" name="sample_text">
<input type="submit" value="Отправить форму методом POST">
</form>

<hr>

<form name="sample_form" action="?" method="GET">
<input type="hidden" name="pmmod" value="sample">
<input type="hidden" name="independ" value="<?php if(! empty($_GET['independ']) || ! empty($_POST['independ'])){echo '1';} ?>">
<input type="test" name="sample_text">
<input type="submit" value="Отправить форму методом GET">
</form>

<p>Для открытия модуля на отдельной странице, не интегрированной в дизайн движка, в GET и POST запросах можно использовать параметр <a href="?pmmod=sample&amp;independ=1">independ со значением 1</a></p>
