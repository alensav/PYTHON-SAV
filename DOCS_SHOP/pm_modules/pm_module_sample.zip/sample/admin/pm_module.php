<?php
 // Если файл загружен не из движка - завершаем программу
 if(! defined('SYS_LOADER')){
 die();
 }
?><h1>Пример администрирования платежного модуля</h1>
<?php

 if(! empty($_POST['sample_text'])){
 echo '<hr>Данные переданные методом &quot;POST&quot;: <span style="color:#0000FF;">'.strip_tags($_POST['sample_text']).'</span><hr>';
 }
 elseif(! empty($_GET['sample_text'])){
 echo '<hr>Данные переданные методом &quot;GET&quot;: <span style="color:#0000FF;">'.strip_tags($_GET['sample_text']).'</span><hr>';
 }

?>

<form action="?" method="POST">
<input type="hidden" name="pmmod" value="sample">
<input type="hidden" name="independ" value="<?php if(! empty($_GET['independ']) || ! empty($_POST['independ'])){echo '1';} ?>">
<input type="test" name="sample_text">
<input type="submit" value="Отправить форму методом POST">
</form>

<hr>

<form action="?" method="GET">
<input type="hidden" name="pmmod" value="sample">
<input type="hidden" name="independ" value="<?php if(! empty($_GET['independ']) || ! empty($_POST['independ'])){echo '1';} ?>">
<input type="test" name="sample_text">
<input type="submit" value="Отправить форму методом GET">
</form>

<p><a href="pages.php?pmmod=sample" target="_blank">Ссылка на модуль в общедоступной части</a>.</p>

<p>Для открытия модуля на отдельной странице, не интегрированной в дизайн движка, в GET и POST запросах можно использовать параметр <a href="?pmmod=sample&amp;independ=1">independ со значением 1</a></p>
