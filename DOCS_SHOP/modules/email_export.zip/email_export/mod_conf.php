<?php
 if(! defined('SYS_LOADER')){
 die();
 }

$mod_conf = array();
$mod_conf['mod_title'] = 'e-mail export' ;

?>