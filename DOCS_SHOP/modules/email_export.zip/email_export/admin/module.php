<?php
 if(! defined('SYS_LOADER')){
 die();
 }

function export_email(){
global $db, $e721eb;
 if(isset($e721eb)){
 $handler = $e721eb;
 }
 elseif(is_object($db->handler)){
 $handler = $db->handler;
 }
 else{
 die('Error');
 }
$table = DB_PREFIX . 'users';
$result = mysqli_query($handler, "SELECT `email`, `first_name`, `patronymic` FROM `$table`") or die(mysqli_error($handler));
 while($row = mysqli_fetch_assoc($result)){
  if($_GET['independ']){
  echo "$row[email]\x0D\x0A";
  }
  else{
  echo "$row[first_name] $row[patronymic] &lt;$row[email]&gt;<br>\n";
  }
 }
}

 if($_GET['independ']){
 header("Pragma: no-cache");
 header("Cache-Control: no-cache, must-revalidate");
 header("Expires: " . gmdate("D, d M Y H:i:s") . " GMT");
 header("Content-Type: application/octet-stream; name=\"export_email.txt\"");
 header("Content-disposition: attachment; filename=export_email.txt");
 }
 else{
 echo '<p><a href="?mod=email_export&independ=1">TXT</a></p>';
 }

export_email();
?>