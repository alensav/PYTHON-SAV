<?php
 // Если файл загружен не из движка - завершаем программу
 if(! defined('SYS_LOADER')){
 die();
 }

$mod_conf = array();
$mod_conf['mod_title'] = 'Загрузка производителей из файла' ;

?>