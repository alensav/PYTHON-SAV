<?php
 // Если файл загружен не из движка - завершаем программу
 if(! defined('SYS_LOADER')){
 die();
 }

 if($_POST['go']){
  if(! empty($_FILES['manufacturers_file']['tmp_name'])){
   if($_FILES['manufacturers_file']['size'] < 1){
   echo '<p class="red">Пустой файл!</p>';
   }
   else{
   echo add_manufacturers($_FILES['manufacturers_file']['tmp_name']);
   }
  }
 }

function add_manufacturers($file){
global $db;
$table = DB_PREFIX . 'manufacturers';
$fh=fopen($file, 'rb') or die("Can't open file '$file'!");
$line = 0;
 while(! feof($fh)){
 $line ++ ;
 $str = trim(fgets($fh, 2048));
  if(empty($str)){
  continue;
  }

 //удаление сигнатоуры (BOM) utf-8 (п»ї)
 if($line == 1 && substr($str, 0, 3) === "\xEF\xBB\xBF"){
 $str = substr($str, 3);
 }

 $sarr = explode(';', $str, 3);
 $mnf_id = intval(trim($sarr[0]));
  if($mnf_id < 1){
  return "<p class=\"red\">Некорректный идентификатор производителя в строке № $line</p>";
  }
 $mnfname = trim($sarr[1]);
  if(empty($mnfname)){
  $mnfname = $mnf_id;
  }
 $title = $sarr[2];
  if(empty($title)){
  return "<p class=\"red\">Не задано название производителя в строке № $line</p>";
  }
 $result = $db->query("SELECT COUNT(*) FROM `$table` WHERE `mnf_id` = '$mnf_id'") or die($db->error());
  if($db->result($result) > 0){
  return "<p class=\"red\">Производитель с идентификатором $mnf_id уже существует (строка № $line)</p>";
  }
 $db->query("INSERT INTO `$table`(`mnf_id`, `mnfname`, `title`, `description`, `image`, `url`, `meta_title`, `meta_description`, `meta_keywords`, `meta_tags`, `sortid`) VALUES('$mnf_id', '$mnfname', '$title', '', '', '', '', '', '', '', '0')") or die($db->error());
 }
fclose($fh);
return '<h3>Данные загружены</h3>';
}

?>
<h3>Загрузка производителей из файла</h3>
загружаемый файл должен быть в кодировке utf-8<br>
Формат файла:<br>
id производителя;имя для ссылок;название производителя<br>
id производителя;имя для ссылок;название производителя<br>
id производителя;имя для ссылок;название производителя<br>
<form name="upload" action="?" method="POST" enctype="multipart/form-data">
<input type="hidden" name="mod" value="add_manufacturers">
<input type="hidden" name="go" value="1">
<input type="file" name="manufacturers_file">
<input type="submit" value="Загрузить">
</form>