<?php
 // Если файл загружен не из движка - завершаем программу
 if(! defined('SYS_LOADER')){
 die();
 }

global $SYS_TEMPLATE_VARS;
$SYS_TEMPLATE_VARS = array();
$SYS_TEMPLATE_VARS['title'] = 'Пример заголовка страницы' ;
$SYS_TEMPLATE_VARS['metatags'] = '<meta name="sample" content="Пример дополнительных мета-тегов">' ;
$SYS_TEMPLATE_VARS['horizontal_menu'] = '&nbsp; <a href="#">Пример ссылки 1</a> | <a href="#">Пример ссылки 2</a>' ;
$SYS_TEMPLATE_VARS['menu_news'] = 'Пример альтернативного блока новостей!<br>...<br>...<br>...<br><br>' ;


?>
<h1>Пример общедоступной части модуля</h1>
<?php

 if(! empty($_POST['sample_text'])){
 echo '<hr>Данные переданные методом &quot;POST&quot;: <span style="color:#0000FF;">'.strip_tags($_POST['sample_text']).'</span><hr>';
 }
 elseif(! empty($_GET['sample_text'])){
 echo '<hr>Данные переданные методом &quot;GET&quot;: <span style="color:#0000FF;">'.strip_tags($_GET['sample_text']).'</span><hr>';
 }

?>

<form name="sample_form" action="?" method="POST">
<input type="hidden" name="mod" value="sample">
<input type="hidden" name="independ" value="<?php if(! empty($_GET['independ']) || ! empty($_POST['independ'])){echo '1';} ?>">
<input type="text" name="sample_text">
<input type="submit" value="Отправить форму методом POST">
</form>

<hr>

<form name="sample_form" action="?" method="GET">
<input type="hidden" name="mod" value="sample">
<input type="hidden" name="independ" value="<?php if(! empty($_GET['independ']) || ! empty($_POST['independ'])){echo '1';} ?>">
<input type="text" name="sample_text">
<input type="submit" value="Отправить форму методом GET">
</form>

<p>Для открытия модуля на отдельной странице, не интегрированной в дизайн движка, в GET и POST запросах можно использовать параметр <a href="?mod=sample&amp;independ=1">independ со значением 1</a></p>
