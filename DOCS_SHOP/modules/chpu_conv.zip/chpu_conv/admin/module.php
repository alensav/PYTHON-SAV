<?php
 // Если файл загружен не из движка - завершаем программу
 if(! defined('SYS_LOADER')){
 die();
 }
?>
<h1>Генерация ссылок ЧПУ в транслите из названий разделов и товаров</h1>
<?php

 if(isset($_POST['conv']))
 {
 echo chpu_conv();
 }
 else
 {
 echo <<<HTMLDATA
<p>
Будут сгенерированы и обновлены имена для ссылок (ЧПУ) из названий разделов и товаров, которые на латинице или на кириллице (ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ абвгдеёжзийклмнопрстуфхцчшщъыьэюя ієїґ ІЄЇҐ).<br>
Для разделов в виде: Nazvanie-razdela-v-translite<br>
Для товаров в виде: Nazvanie-tovara-v-translite<br>
Длинные названия будут обрезаны.<br>
Пробелы будут заменены на -<br>
Не буквенные символы (см.перечисленные выше) и не числовые символы кроме - и _ будут удалены.<br>
Если какие-то названия повторяются, то к ним будет добавлен числовой идентификатор в конец.<br>
<b>Предварительно сделайте резервную копию базы данных.</b>
</p>

<form name="frm" action="?" method="POST" onsubmit="this.submit.disabled=true;">
<input type="hidden" name="mod" value="chpu_conv">
<input type="hidden" name="conv" value="1">
<input type="submit" name="submit" value="Конвертировать ссылки">
</form>
HTMLDATA;
 }



function chpu_conv(){
global $db;

echo '<p>Информация отображена в виде<br><b>Идентификатор раздела(товара): имя для ссылок</b></p><h2>Категории товаров</h2>';
$table = DB_PREFIX.'categories';
$res = $db->query("SELECT `catid`, `fcatname`, `title` FROM `$table` WHERE `catid` <> 0") or die ($db->error());

$categories = array();

 while($row = $db->fetch_assoc($res))
 {
 array_push($categories, $row);
 }

$new_catnames = array();

 foreach($categories as $row)
 {
 $old_catname = chpu_catname_from_fullcatname($row['fcatname']);
 $new_fcatname = substr($row['fcatname'], 0, strlen($row['fcatname']) - strlen($old_catname));
 $new_catname = chpu_conv_name($row['title']);
 $new_catname = substr($new_catname, 0, 42);

  if(in_array($new_catname, $new_catnames))
  {
  echo "<b class=\"red\">$row[catid]: Имя раздела уже есть: $new_catname</b><br>";
  $new_catname .= "-$row[catid]";
  }

 $new_fcatname .= $new_catname;

 echo "$row[catid]: $new_catname<br>";

 $db->query("UPDATE `$table` SET `fcatname` = '$new_fcatname' WHERE `catid` = '$row[catid]'") or die ($db->error());
 array_push($new_catnames, $new_catname);
 }


require_once(INC_DIR.'/admin/ed_cat.php');

 if(class_exists('ed_category')){
 $ec = new ed_category;
 }
 else{
 //совместимость с версиями ниже 3.2
 $ec = new blsz5tb3jr2;
 }

$categories = array();
$res = $db->query("SELECT `catid` FROM `$table` WHERE catid <> 0 AND `parent` = 0") or die ($db->error());
 while($row = $db->fetch_assoc($res)){
 array_push($categories, $row['catid']);
 }

 //переименование fulltitle подразделов
 foreach($categories as $catid){
  if(method_exists('ed_category', 'rename_subchapters_fulltitle')){
  $ec->rename_subchapters_fulltitle($catid);
  }
  else{
  //совместимость с версиями ниже 3.2
  $ec->rba5vbsosczp5utbrosesiitytib($catid);
  }
 }


echo '<p><hr></p><h2>Товары</h2>';
$table = DB_PREFIX.'items';
$res = $db->query("SELECT `itemid`, `itemname`, `title` FROM `$table`") or die ($db->error());

$items = array();

 while($row = $db->fetch_assoc($res))
 {
 array_push($items, $row);
 }

$new_itemnames = array();

 foreach($items as $row)
 {
 $itemname = chpu_conv_name($row['title']);
 $itemname = substr($itemname, 0, 240);

  if(in_array($itemname, $new_itemnames)){
  echo "<b class=\"red\">$row[itemid]: Имя товара уже есть: $itemname</b><br>";
  $itemname .= "-$row[itemid]";
  }

 echo "$row[itemid]: $itemname<br>";

 $db->query("UPDATE `$table` SET `itemname` = '$itemname' WHERE `itemid` = '$row[itemid]'") or die ($db->error());
 array_push($new_itemnames, $itemname);
 }


return '<h3>Конвертация завершена</h3>';
}



function chpu_conv_name($rus_text){
$ret = str_replace('&quot;', '', $rus_text);
$ret = str_replace('&#39;', '', $ret);
$ret = chpu_translit_rus_lat($ret);
//Замена все 2-е пробелы и символы табуляции одинарными пробелами
$ret = preg_replace("/[\x09\x20]+/", ' ', $ret);
$ret = str_replace(' ', '-', $ret);
//удаление 2-х -
$ret = preg_replace("/[\-]+/", '-', $ret);
//return preg_replace("([^0-9a-zA-Z\x80-\xFF\x20\_\-])", '', $ret);
return preg_replace("([^0-9a-zA-Z\x20\_\-])", '', $ret);
}



function chpu_translit_rus_lat($str){
$ru_chars = array('а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'yo','ж'=>'zh','з'=>'z','и'=>'i','й'=>'j','к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f','х'=>'h','ц'=>'ts','ч'=>'ch','ш'=>'sh','щ'=>'shh','ъ'=>'','ы'=>'i','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya','А'=>'A','Б'=>'B','В'=>'V','Г'=>'G','Д'=>'D','Е'=>'E','Ё'=>'YO','Ж'=>'ZH','З'=>'Z','И'=>'I','Й'=>'J','К'=>'K','Л'=>'L','М'=>'M','Н'=>'N','О'=>'O','П'=>'P','Р'=>'R','С'=>'S','Т'=>'T','У'=>'U','Ф'=>'F','Х'=>'H','Ц'=>'TS','Ч'=>'CH','Ш'=>'SH','Щ'=>'SHH','Ъ'=>'','Ы'=>'I','Ь'=>'','Э'=>'E','Ю'=>'YU','Я'=>'YA','і'=>'i','ґ'=>'g','є'=>'e','ї'=>'yi','І'=>'I','Ґ'=>'G','Є'=>'E','Ї'=>'YI');
$str = strtr($str, $ru_chars);
//преобразование "CHtenie" в "Chtenie" отдельно по каждому слову
return preg_replace_callback('/([A-Z]{2,3})([a-z]{1,})/', 'translit_ucfirst', $str);
}


function translit_ucfirst($matches){
return ucfirst(strtolower($matches[0]));
}


//возвращает имя последнего подраздела из полного имени $fullcatname
function chpu_catname_from_fullcatname($fullcatname){
$pos = strrpos($fullcatname, '/');
 if($pos)
 {
 return substr($fullcatname, $pos+1);
 }
 else
 {
 return $fullcatname;
 }
}


?>