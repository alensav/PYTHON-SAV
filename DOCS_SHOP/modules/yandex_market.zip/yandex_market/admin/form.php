<?php
// Copyright (c) Igor Anikeev http://www.arwshop.ru/

if(! defined('SYS_LOADER')){die();}
$ymlset = $custom->get_settings(5);

 if(isset($act) && $act == 'do_export'){
 $result = export_yandex_market();
  if($result == 1){
  echo "<h3>$lang[export_completed]</h3>";
  echo "$lang[qw_exported_products] $exp_results[qw_exported_products]<br>";

   if($exp_results['not_in_stock'] > 0){
   echo "$lang[from_them_not_in_stock] $exp_results[not_in_stock]<br>";
   }

   echo "<hr>";

    if($ymlset['no_export_no_in_stock'] && $exp_results['not_in_stock_all'] > 0){
    echo "$lang[not_in_stock] $exp_results[not_in_stock_all]<br>";
    }

   if($exp_results['null_price'] > 0){
   echo "$lang[null_price_products] $exp_results[null_price]";
   }
  }
  else{
  echo "<font class=\"red\">$result</font>";
  }
 }
 elseif(isset($act) && $act == 'save_selected_products'){
 echo save_selected_products();
 }


 if(empty($ymlset['shop_name'])){
 $ymlset['shop_name'] = mb_substr($sett['shop_name'], 0, 120);
 }

 if(empty($ymlset['company_name'])){
 $ymlset['company_name'] = $sett['shop_name'];
 }

?>
<h1><?php echo $mod_conf['mod_title']; ?></h1><?php

$required_engine_version = 3.2;
 if(custom::floatVersion() < $required_engine_version){
 die('<p class="red">Required ' . custom::product_name() . ' ' . $required_engine_version . ' or higher!</p>');
 }

 if(file_exists(SCRIPTCHF_DIR."/adm/dump/$yml_file")){
 echo "<p>$lang[download_link] <a href=\"$sett[url]$sett[index_file]?mod=$mod&amp;download=1&amp;independ=1\" target=\"_blank\">$sett[url]$sett[index_file]?mod=$mod&amp;download=1&amp;independ=1</a></p>";
 }

$tbl_items=DB_PREFIX.'items';
$tbl_categories=DB_PREFIX.'categories';
$res = $db->query("SELECT COUNT(*) FROM $tbl_items, $tbl_categories WHERE $tbl_items.visible = 1 AND $tbl_categories.catid = $tbl_items.catid") or die($db->error());
$qw_items = $db->result($res, 0, 0);
 if(empty($yml_items[0])){
 @array_shift($yml_items);
 }
$qw_selected_items = sizeof($yml_items);
?><form action="?" method="POST">
<input type="hidden" name="mod" value="<?php echo $mod; ?>">
<input type="hidden" name="act" value="do_export">

<p><a href="?mod=<?php echo $mod; ?>&amp;act=select_products"><?php echo $lang['select_products']; ?></a><?php echo "<br>($lang[is_selected] $qw_selected_items $lang[from] $qw_items $lang[available_in_shop])"; ?></p>

<p><?php echo $lang['export_currencies_info']; ?></p>

<p><?php echo $lang['description_info']; ?></p>

<p><?php echo $lang['available_products_info']; ?></p>

<table width="100%" class="settbl">
 <tr class="htr">
  <td colspan="2"><?php echo "$lang[shop_settings]"; ?></td>
 </tr>

 <tr class="str">
  <td><?php echo $lang['shop_name']; ?></td>
  <td><input type="text" name="new_sett[shop_name]" value="<?php echo $ymlset['shop_name']; ?>" size="38" maxlength="20"></td>
 </tr>

 <tr class="ttr">
  <td><?php echo $lang['company_name']; ?></td>
  <td><input type="text" name="new_sett[company_name]" value="<?php echo $ymlset['company_name']; ?>" size="38"></td>
 </tr>

</table>

<p><input type="checkbox" name="new_sett[no_export_no_in_stock]"<?php if(! empty($ymlset['no_export_no_in_stock'])){echo ' checked';} ?>> <?php echo "$lang[no_export_no_in_stock]<br>$lang[export_no_in_stock_info]"; ?></p>

<p><a href="javascript:window.open('?mod=<?php echo $mod; ?>&amp;act=products_add_par&amp;independ=1','','status,scrollbars,resizable,width=730,height=600');void(0);"><?php echo $lang['products_add_par']; ?></a></p>

<p><input type="submit" value="<?php echo $lang['do_export']; ?>" class="button1"></p>
</form>