<?php
// Copyright (c) Igor Anikeev http://www.arwshop.ru/

//Проверка прайс-листа на ошибки: https://partner.market.yandex.ru/  Подключение и настройки / Общие настройки / Прайс-лист ...ссылка на файл сайта... изменить 
 
//При генерации YML-файла необходимо соблюдать очередность тегов как здесь http://partner.market.yandex.ru/legal/tt/ иначе при проверке будет выдавать ошибку "Element 'TAGNAME' is not valid for content model"
if(! defined('SYS_LOADER')){die();}
global $sett, $mod_conf, $db, $ymlset, $yml_file, $yml_items, $exp_results, $lang, $delivery_options_fields;

$delivery_options_fields = array('cost', 'days', 'order-before');

$act = '';
$file_type = '';

 if($_SERVER['REQUEST_METHOD'] == 'GET'){
 $act = isset($_GET['act']) ? $_GET['act'] : '';
 $file_type = isset($_GET['file_type']) ? $_GET['file_type'] : '';
 }
 elseif($_SERVER['REQUEST_METHOD'] == 'POST'){
 $act = isset($_POST['act']) ? $_POST['act'] : '';
 $file_type = isset($_POST['file_type']) ? $_POST['file_type'] : '';
 }

load_mod_language();
include(MODULES_DIR."/$mod/mod_conf.php");
$ymlset = $custom->get_settings(5);
$yml_file = 'yandex_market.xml';
//получаем itemid товаров, которые следует экспортировать и объединяем в массив с пом. explode
$yml_items = explode(';', $custom->get_txtsettings('yml_items'));
 if($yml_items[0] === ''){
 @array_shift($yml_items);
 }
sort($yml_items, SORT_STRING);

 if(isset($act) && $act == 'select_products'){
 select_products_form();
 }
 elseif(isset($act) && $act == 'products_add_par'){
 echo products_add_par_form();
 }
 else{
 include(MODULES_DIR."/$mod/admin/form.php");
 }


function export_yandex_market(){
global $db, $custom, $lang, $sett, $ymlset, $admin_lib, $yml_file, $yml_items, $exp_results, $admset, $delivery_options_fields;

if(! $admin_lib->check_admin_perms()){return $admin_lib->nosave_perms_msg();}

 if(function_exists('set_time_limit')){
 @set_time_limit(300);
 }

$manufacturers = ym_get_all_manufacturers();

$tbl_currencies = DB_PREFIX.'currencies';
$tbl_categories = DB_PREFIX.'categories';
$tbl_items = DB_PREFIX.'items';

$_POST['new_sett'] = $custom->trim_array($_POST['new_sett']);

$crlf = "\n";

$yi_size = count($yml_items);

$err = '';

 if(empty($_POST['new_sett']['shop_name'])){
 $err .= "$lang[empty_shop_name]<br>";
 }

 if(empty($_POST['new_sett']['company_name'])){
 $err .= "$lang[empty_company_name]<br>";
 }

 if($err){
 return $err;
 }

$_POST['new_sett']['shop_name'] = trim(mb_substr($_POST['new_sett']['shop_name'], 0, 120));
$_POST['new_sett']['company_name'] = trim($_POST['new_sett']['company_name']);

 if(! empty($_POST['new_sett']['no_export_no_in_stock'])){
 $_POST['new_sett']['no_export_no_in_stock'] = 1;
 }
 else{
 $_POST['new_sett']['no_export_no_in_stock'] = 0;
 }

$admin_lib->save_settings(5, $_POST['new_sett']);
$ymlset = $custom->get_settings(5);

$fh = @fopen(SCRIPTCHF_DIR."/adm/dump/$yml_file", 'wb');

 if(! $fh){
 return "$lang[cant_write_to_file] \"".SCRIPTCHF_DIR."/adm/dump/$yml_file\"<br>$lang[check_chmod] \"".SCRIPTCHF_DIR."/adm/dump\"<br>";
 }


$ymlset['shop_name'] = mb_substr(format_yml_text($ymlset['shop_name']), 0, 120);
$ymlset['company_name'] = format_yml_text($ymlset['company_name']);


$date = date("Y-m-d H:i", intval(time() + $sett['time_diff'] * 3600));
$data = "<?xml version=\"1.0\" encoding=\"$sett[charset]\"?>$crlf";
$data .= "<!DOCTYPE yml_catalog SYSTEM \"shops.dtd\">$crlf";
$data .= " <yml_catalog date=\"$date\">$crlf";
$data .= "  <shop>$crlf";
$data .= "   <name>$ymlset[shop_name]</name>$crlf";
$data .= "   <company>$ymlset[company_name]</company>$crlf";
$data .= "   <url>$sett[url]$sett[index_file]</url>$crlf";
$data .= "   <currencies>$crlf";

unset($date);



//get currencies
$tbl_currencies=DB_PREFIX.'currencies';
$res = $db->query("SELECT * FROM $tbl_currencies WHERE enabled = 1") or die($db->error());
$currencies = array();

 //если в дополнительных параметрах задано значение валюты, в которой будут экспортироваться цены
 if(! empty($ymlset['yml_curr_id'])){
 $export_curr_id = $ymlset['yml_curr_id'];
 }
 else{
 $export_curr_id = 0;
 }

 while($row=$db->fetch_array($res)){
  if(strlen($row['iso_alpha'])==3){
  $currencies["$row[currency_id]"] = $row;
    //если в дополнительных параметрах не задано значение валюты, в которой будут экспортироваться цены
    //и $row['iso_alpha']==='RUR'
   if($export_curr_id == 0 && $row['iso_alpha'] === 'RUR'){
   $export_curr_id = $row['currency_id'];
   }
  }
 }

 //если в дополнительных параметрах не задано значение валюты, в которой будут экспортироваться цены
 //и валюта с кодом iso_alpha RUR отсутствует
 if($export_curr_id == 0){
 return "$lang[rur_not_exists]<br>";
 }
 //если в дополнительных параметрах задано значение валюты, в которой будут экспортироваться цены
 //но отсутствует значение iso_alpha для этой валюты
 elseif(empty($currencies["$export_curr_id"]['iso_alpha'])){
 return "$lang[not_exists_iso_alpha]<br>";
 }

 foreach($currencies as $name => $row){
 //вычисляем правильный курс, независимо от того какая валюта используется по умолчанию
 $row['course'] = $row['course'] / $currencies["$export_curr_id"]["course"];
 $data .= "    <currency id=\"$row[iso_alpha]\" rate=\"$row[course]\"/>$crlf";
 }



$data .= "   </currencies>$crlf";


//END get currencies



put_to_ymlfile($fh, $data);





//get categories
put_to_ymlfile($fh, "   <categories>$crlf");

$res = $db->query("SELECT catid, fcatname, parent, title FROM $tbl_categories WHERE catid <> 0 ORDER BY catid") or die($db->error());

$fcatnames=array();

 while($row = $db->fetch_array($res)){
 $fcatnames["$row[catid]"]=$row['fcatname'];
  if($row['parent'] > 0){
  $row['parent'] = " parentId=\"$row[parent]\"";
  }
  else{
  $row['parent'] = '';
  }
 put_to_ymlfile($fh, "    <category id=\"$row[catid]\"$row[parent]>" . format_yml_text($row['title']) . "</category>$crlf");
 }

put_to_ymlfile($fh, "   </categories>$crlf");
//END get categories





$delivery_options = unpack_options(custom::get_txtsettings('yml_delivery_options'));
 if(count($delivery_options) > 0){
 put_to_ymlfile($fh, "   <delivery-options>$crlf");
  foreach($delivery_options as $opt_arr){
  $option = '<option';
   foreach($opt_arr as $name => $value){
    if($name !== '' && $value !== ''){
    $option .= " $name=\"$value\"";
    }
   }
  put_to_ymlfile($fh, "     $option/>$crlf");
  }
 put_to_ymlfile($fh, "   </delivery-options>$crlf");
 }

$max_delivery_options = 5;
$delivery_options_quantity = count($delivery_options);
 if($delivery_options_quantity < $max_delivery_options){
  for($i = 0; $i < $max_delivery_options; $i++){
   if(! isset($delivery_options[$i])){
    foreach($delivery_options_fields as $field_name){
    $delivery_options[$i][$field_name] = '';
    }
   }
  }
 }






//get products
put_to_ymlfile($fh, "   <offers>$crlf");

$res = $db->query("SELECT * FROM $tbl_items WHERE visible = 1 ORDER BY itemid") or die($db->error());

$exp_results = array();
$exp_results['qw_exported_products'] = 0;
$exp_results['not_in_stock'] = 0;
$exp_results['not_in_stock_all'] = 0;
$exp_results['null_price'] = 0;

//корневой URL сайта
$base_site_url_ws = site_base_url($sett['url']);
//корневой URL сайта без слэша в конце
$base_site_url_ws = substr($base_site_url_ws, 0, strlen($base_site_url_ws) - 1);

 while($row = $db->fetch_array($res)){

  //if(in_array($row['itemid'], $yml_items)){
  if(yml_get_arr_key($row['itemid'], $yml_items, $yi_size) != -1){
  $row['fcatname']=$fcatnames["$row[catid]"];

   if($row['quantity'] < 1){
   $exp_results['not_in_stock_all']++;
   }

   if($row['price'] > 0 && ($row['quantity'] > 0 || ! $ymlset['no_export_no_in_stock']) ){

    if($row['quantity'] > 0){
    $available = 'true';
    }
    else{
    $available = 'false';
    $exp_results['not_in_stock']++;
    }

   $data = "    <offer id=\"$row[itemid]\" available=\"$available\">$crlf";
   $url = format_yml_text($base_site_url_ws . stdi2("product=$row[itemid]", $custom->statlink($row['fcatname'], "$row[itemname].html", "product$row[itemid].html", 'p')));
   $data .= "      <url>$url</url>$crlf";
   $price = pricef($row['price'] / $currencies["$export_curr_id"]["course"]); 
   $data .= "      <price>$price</price>$crlf";

    if(! empty($ymlset['use_old_price']) && $row['old_price'] > $row['price']){
    $row['old_price'] = pricef($row['old_price'] / $currencies["$export_curr_id"]["course"]);
    $data .= "      <oldprice>$row[old_price]</oldprice>$crlf";
    }

   $data .= '      <currencyId>'.$currencies["$export_curr_id"]['iso_alpha']."</currencyId>$crlf";
   $data .= "      <categoryId>$row[catid]</categoryId>$crlf";

    if($row['small_img']){
    $picture = format_yml_text("$sett[url]img/small/$row[small_img]");
    }
    elseif($row['big_img']){
    $picture = format_yml_text("$sett[url]img/big/$row[big_img]");
    }
    else{
    $picture = '';
    }

    $picture = trim($picture);

    if($picture){
    $picture = str_replace(' ', '%20', $picture);
    $data .= "      <picture>$picture</picture>$crlf";
    }

    $tfvalue = get_true_false_str('store');
    if($tfvalue){
    $data .= "      <store>$tfvalue</store>$crlf";
    }

    $tfvalue = get_true_false_str('pickup');
    if($tfvalue){
    $data .= "      <pickup>$tfvalue</pickup>$crlf";
    }

    $tfvalue = get_true_false_str('delivery');
    if($tfvalue){
    $data .= "      <delivery>$tfvalue</delivery>$crlf";
    }

/* local_delivery_cost Устарело - Используется только в форматах XLS, CSV https://yandex.ru/support/partnermarket/offers.html
вместо него теперь delivery-options (Необязательный элемент)
    if($ymlset['local_delivery_cost'] !== ''){
    $ymlset['local_delivery_cost'] = pricef($ymlset['local_delivery_cost']);
    $data .= "      <local_delivery_cost>$ymlset[local_delivery_cost]</local_delivery_cost>$crlf";
    }
*/
    if(! empty($ymlset['use_vendor']) && $row['mnf_id'] > 0 && ! empty($manufacturers[$row['mnf_id']]['title'])){
    $data .= "      <vendor>" . format_yml_text($manufacturers[$row['mnf_id']]['title']) . "</vendor>$crlf";
    }

   $data .= "      <name>" . format_yml_text($row['title']) . "</name>$crlf";

    if($row['short_descript']){
    $description = $row['short_descript'];
    }
    else{
    $description = $row['long_descript'];
    }

   //чтобы были пробелы в местах удаления тегов
   $description = str_replace('>', '> ', $description);
   $description = delete_double_crlf($description, 1);
   $description = delete_double_spaces($description);
   $description = format_yml_text($description);
    //раньше было макс.255, теперь 3000
    if(mb_strlen($description) > 3000){
    $description = cutstr_whith_full_last_word($description, 2997) . '...';
    }
   $data .= "      <description>$description</description>$crlf";

   $ymlset['sales_notes'] = isset($ymlset['sales_notes']) ? trim(mb_substr(format_yml_text($ymlset['sales_notes']), 0, 50)) : '';
    if($ymlset['sales_notes']){
    $data .= "      <sales_notes>$ymlset[sales_notes]</sales_notes>$crlf";
    }

   $data .= "    </offer>$crlf";

   put_to_ymlfile($fh, $data);
   $exp_results['qw_exported_products']++;

   }
   //если цена < 0.01
   else{
   $exp_results['null_price']++;
   }


  }


 }

put_to_ymlfile($fh, "   </offers>$crlf");
//END get products







$data = "  </shop>$crlf";
$data .= " </yml_catalog>$crlf";

put_to_ymlfile($fh,$data);
@fclose($fh);

 if($exp_results['qw_exported_products'] < 1){
 @unlink(SCRIPTCHF_DIR."/adm/dump/$yml_file");
 }
 else{
  if($admset['set_rfiles_chmod']){
   if(is_numeric($admset['rfiles_chmod']) && is_file(SCRIPTCHF_DIR."/adm/dump/$yml_file")){
   @chmod(SCRIPTCHF_DIR."/adm/dump/$yml_file", octdec($admset['rfiles_chmod']));
   }
  }
 }

return 1;
}




function put_to_ymlfile($fh,$data){
return @fputs($fh, $data);
}


function format_yml_text($text){
$text = strip_tags(stripslashes($text));

//Стандарт XML не допускает использования в текстовых данных непечатаемых символов с ASCII-кодами в диапазоне значений от 0 до 31 (за исключением символов с кодами 9, 10, 13 - табуляция, перевод строки, возврат каретки). Также этот стандарт требует обязательной замены некоторых символов (см. таблицу) на эквивалентные им символьные примитивы.

//замена символов с кодами 0 - 31 на пробел (кроме символов с кодами 9, 10, 13)
$text = preg_replace('([\x00-\x08\x0B\x0C\x0E-\x1F])', ' ', $text);

//замена & на &amp; кроме &quot; &nbsp; &#39; и т.п.
//здесь не нужно но пригодится для другого!
//$text = preg_replace('/\&(?![a-zA-Z\#][a-zA-Z\#\d]+?\;)/', '&amp;', $text);

//замена &nbsp; на пробелы
$text = str_replace('&nbsp;', ' ', $text);

//замена & на &amp; кроме &#39; (и т.п. числовых) &quot; &amp; &gt; &lt; &apos;
$text = preg_replace("((\&)(?!(\#[0-9]{1,5}\;|quot\;|amp\;|gt\;|lt\;|apos\;)))", '&amp;', $text);

$text = str_replace('"', '&quot;', $text);
$text = str_replace('>', '&gt;', $text);
$text = str_replace('<', '&lt;', $text);
$text = str_replace("'", '&apos;', $text);
$text = str_replace('&#39;', '&apos;', $text);

return $text;
}


function select_products_form(){
global $db, $lang, $custom, $yml_items, $mod_conf, $mod;

 if(function_exists('set_time_limit')){
 @set_time_limit(300);
 }

$tbl_items=DB_PREFIX.'items';
$tbl_categories=DB_PREFIX.'categories';

$res = $db->query("SELECT $tbl_items.itemid, $tbl_items.title, $tbl_categories.catid, $tbl_categories.fulltitle FROM $tbl_items, $tbl_categories WHERE $tbl_items.visible = 1 AND $tbl_categories.catid = $tbl_items.catid ORDER BY $tbl_categories.fulltitle, $tbl_items.title") or die($db->error());

$old_cat=0;
$reg_exp = '/(products\[)([0-9]{1,})(\]\[)([0-9]{1,})(\])/g';

echo <<<HTMLDATA
<script type="text/javascript">
var max_i=0;
function sel_all(){
 if(document.getElementById('pr[0]')==null){
 return false;
 }
var check_value=false;
 if(document.getElementById('pr[0]').checked==true){
 check_value=false;
 }
 else{
 check_value=true;
 }
 for(i=0;i<max_i;i++){
 document.getElementById('pr['+i+']').checked=check_value;
 }
return false;
}
function sel_allc(catid){
var check_value=false;
var itemcat=0;
var defobj=new Object;
var begined=0;
 for(i=0;i<max_i;i++){
 defobj=document.getElementById('pr['+i+']');
 itemcat=get_item_cat(defobj.name);
  if(itemcat==catid){
   if(! begined){
    if(defobj.checked==true){
    check_value=false;
    }
    else{
    check_value=true;
    }
   }
  defobj.checked=check_value;
  begined=1;
  }
 }
return false;
}
function get_item_cat(itemname){
var pos1=itemname.indexOf('[');
var pos2=itemname.indexOf(']');
return itemname.substring(pos1+1,pos2);
}
function sendForm(){
document.frm.selected_products.value='';
 for(i=0;i<max_i;i++){
 var el=document.getElementById('pr['+i+']');
  if(el.checked){
  var prid = el.name.replace($reg_exp, '\$4');
  document.frm.selected_products.value+=prid+';';
  }
 }
document.frm.action='?';
document.frm.submit();
}
</script>

<h3><a href="?mod=$mod">$mod_conf[mod_title]</a></h3>
<h5>$lang[select_products]</h5>

<form name="frm" action="javascript:sendForm();" method="POST">
<input type="hidden" name="mod" value="$mod">
<input type="hidden" name="act" value="save_selected_products">
<input type="hidden" name="selected_products">
</form>
<p><a href="#" onclick="return sel_all()">$lang[select_all]</a> &nbsp; &nbsp; &nbsp; <button class="button1" onclick="sendForm();">$lang[submit]</button></p>
HTMLDATA;

$i=0;

$yi_size = count($yml_items);

 while($row = $db->fetch_array($res)){

  //if(in_array($row['itemid'], $yml_items)){
  //ускоренный in_array (нужен отсортированный массив методом СТРОКОВОЙ сортировки)
  if(yml_get_arr_key($row['itemid'], $yml_items, $yi_size) != -1){
  $checked=' checked="checked"';
  }
  else{
  $checked='';
  }

  if($row['catid'] != $old_cat){
  echo "<br><b>$row[fulltitle]</b><br><a href=\"#\" onclick=\"return sel_allc($row[catid])\">$lang[select_all]</a><br>";
  }

 echo "<input type=\"checkbox\" name=\"products[$row[catid]][$row[itemid]]\" id=\"pr[$i]\"$checked>$row[title]<br>";
 $old_cat=$row['catid'];
 $i++;
 }


echo <<<HTMLDATA
<script type="text/javascript">
max_i=$i;
</script>
<p><button class="button1" onclick="sendForm();">$lang[submit]</button></p>
HTMLDATA;


}



function save_selected_products(){
global $db, $lang, $admin_lib, $custom, $yml_items;

if(! $admin_lib->check_admin_perms()){return $admin_lib->nosave_perms_msg();}

$tbl_txtsettings=DB_PREFIX.'txtsettings';

/*
$yml_items='';
 if(sizeof($_POST['products'])){
  foreach($_POST['products'] as $catid => $arr){
   if(sizeof($arr)){
    foreach($arr as $itemid => $value){
     if($value){
     $yml_items.="$itemid;";
     }
    }
   }
  }
 }
*/

 if(strlen($_POST['selected_products']) > 0){
 $_POST['selected_products'] = substr($_POST['selected_products'], 0, strlen($_POST['selected_products']) - 1);
 }

$admin_lib->save_txtsettings(array('yml_items' => $_POST['selected_products']));
unset($_POST['selected_products']);

//получаем itemid товаров, которые следует экспортировать и объединяем в массив с пом. explode
$yml_items = explode(';', $custom->get_txtsettings('yml_items'));

return "<h3>$lang[changes_success]</h3>";
}



//всегда возвращает корневой URL сайта (с / в конце) из любого URL адреса
function site_base_url($url){
$pos = strpos($url, '://');
 if(! $pos){
 return '';
 }
$pos = strpos($url, '/', $pos+3);
 if($pos){
 return substr($url, 0, $pos+1);
 }
 else{
 return substr($url, 0) . '/';
 }
}


//Заменяет все 2-е пробелы и символы табуляции одинарными пробелами
function delete_double_spaces($str){
return preg_replace("/[\x09\x20]+/", ' ', $str);
}



//удалаяет все 2-е символы новой строки (предварително удаляет все символы с кодом 13, если указано в параметре)
function delete_double_crlf($data, $delete_13 = false){
 if($delete_13){
 $data = custom::rn_to_n($data);
 }
 else{
 $pos = -1;
  while($pos !== false){
  $pos = strpos($data, "\x0D\x0A\x0D\x0A");
  if($pos){$data = str_replace("\x0D\x0A\x0D\x0A", "\x0D\x0A", $data);}
  }
 }

$pos = -1;
 while($pos !== false){
 $pos = strpos($data, "\x0A\x0A");
 if($pos){$data = str_replace("\x0A\x0A", "\x0A", $data);}
 }
return $data;
}



//обрезает строку до заданного кол-ва символов
//всегда оставляя последнее слово целым, если последнее слово обрезается посередине, то оно отбрасывается
function cutstr_whith_full_last_word($data, $length){
 if(mb_strlen($data) <= $length){
 return $data;
 }
//при экспорте в XML ни в коем случае нельзя включать в список разделителей точку с запятой!
$delimiters = array(" ", "\x09",  "\x0A", '.', ',', ':');

 //если следующий после $length символ является разделителем
 if(in_array(mb_substr($data, $length, 1), $delimiters)){

 return mb_substr($data, 0, $length);

 }
 else{

 $data = mb_substr($data, 0, $length);
 $max_delimiter_pos = 0;
  foreach($delimiters as $delimiter){
  $pos = mb_strrpos($data, $delimiter);
   if($pos > 0){
    if($pos > $max_delimiter_pos){
    $max_delimiter_pos = $pos;
    }
   }
  }

 return mb_substr($data, 0, $max_delimiter_pos);

 }

}



function products_add_par_form(){
global $sett, $lang, $ymlset, $admin_lib, $mod, $delivery_options_fields;
$ret='';

 if(! empty($_POST['save_products_add_par'])){
 $ret .= save_products_add_par();
 }

$products_add_par_descript = custom::contextHelp($lang['products_add_par_descript']);
$ret.=<<<HTMLDATA
<!DOCTYPE html><html><head><meta http-equiv="content-type" content="text/html; charset=$sett[charset]"><title>$lang[products_add_par]</title>
<link href="adm/pop-up.css" rel="stylesheet" type="text/css">
<link href="ht/custom.css" rel="stylesheet" type="text/css">
</head><body style="background:#ffffff;padding:2px;">
<form name="frm" action="?" method="POST">
<input type="hidden" name="mod" value="$mod">
<input type="hidden" name="act" value="products_add_par">
<input type="hidden" name="save_products_add_par" value="1">
<input type="hidden" name="independ" value="1">
<h3>$lang[products_add_par] $products_add_par_descript</h3>

<table width="100%" class="settbl">
 <tr class="htr">
  <td>$lang[tag_name]</td>
  <td>$lang[tag_value]</td>
 </tr>
HTMLDATA;

 if(! isset($ymlset['yml_curr_id'])){
 $ymlset['yml_curr_id'] = 0;
 }
$currencies_list = yml_currencies_list($ymlset['yml_curr_id']);
$def_class = $admin_lib->sett_class();

$ret .= <<<HTMLDATA
 <tr class="$def_class">
  <td>$lang[export_currency]</td>
  <td><select name="new_sett[yml_curr_id]">
  <option value="0">$lang[default_currency] (RUR)</option>
  $currencies_list
  </select>
  </td>
 </tr>
HTMLDATA;



$ret .= '<tr class="' . $admin_lib->sett_class() .'"><td>' . $lang['use_old_price'] . ' ' . custom::contextHelp($lang['use_old_price_help']) . '</td><td><input type="radio" name="new_sett[use_old_price]" value="1"';
 if(! empty($ymlset['use_old_price'])){
 $ret .=  ' checked="checked"';
 }
$ret .= '> ' . $lang['yes'] . ' &nbsp; <input type="radio" name="new_sett[use_old_price]" value="0"';
 if(empty($ymlset['use_old_price'])){
 $ret .=  ' checked="checked"';
 }
$ret .= '> ' .$lang['no'] . '</td></tr>';




$ret .= '<tr class="' . $admin_lib->sett_class() .'"><td>' . $lang['use_vendor'] . ' ' . custom::contextHelp($lang['use_vendor_help']) . '</td><td><input type="radio" name="new_sett[use_vendor]" value="1"';
 if(! empty($ymlset['use_vendor'])){
 $ret .=  ' checked="checked"';
 }
$ret .= '> ' . $lang['yes'] . ' &nbsp; <input type="radio" name="new_sett[use_vendor]" value="0"';
 if(empty($ymlset['use_vendor'])){
 $ret .=  ' checked="checked"';
 }
$ret .= '> ' .$lang['no'] . '</td></tr>';



$def_class = $admin_lib->sett_class();
$schecked = get_sett_checked('store');

$ret.=<<<HTMLDATA
 <tr class="$def_class">
  <td>$lang[store]</td>
  <td><input type="radio" name="new_sett[store]" value="1"$schecked[true]> $lang[yes] &nbsp; <input type="radio" name="new_sett[store]" value="0"$schecked[false]> $lang[no] &nbsp; <input type="radio" name="new_sett[store]" value=""$schecked[not_use]> $lang[not_use]</td>
 </tr>
HTMLDATA;

$def_class = $admin_lib->sett_class();
$schecked = get_sett_checked('pickup');
$pickup_help = custom::contextHelp($lang['pickup_help']);

$ret.=<<<HTMLDATA
 <tr class="$def_class">
  <td>$lang[pickup] $pickup_help</td>
  <td><input type="radio" name="new_sett[pickup]" value="1"$schecked[true]> $lang[yes] &nbsp; <input type="radio" name="new_sett[pickup]" value="0"$schecked[false]> $lang[no] &nbsp; <input type="radio" name="new_sett[pickup]" value=""$schecked[not_use]> $lang[not_use]</td>
 </tr>
HTMLDATA;

$def_class = $admin_lib->sett_class();
$schecked = get_sett_checked('delivery');
$delivery_help = custom::contextHelp($lang['delivery_help']);

$ret .= <<<HTMLDATA
 <tr class="$def_class">
  <td>$lang[delivery] $delivery_help</td>
  <td><input type="radio" name="new_sett[delivery]" value="1"$schecked[true]> $lang[yes] &nbsp; <input type="radio" name="new_sett[delivery]" value="0"$schecked[false]> $lang[no] &nbsp; <input type="radio" name="new_sett[delivery]" value=""$schecked[not_use]> $lang[not_use]</td>
 </tr>
HTMLDATA;

/* local_delivery_cost Устарело - Используется только в форматах XLS, CSV https://yandex.ru/support/partnermarket/offers.html
вместо него теперь delivery-options (Необязательный элемент)
$ret.=<<<HTMLDATA
 <tr class="$def_class">
  <td>$lang[local_delivery_cost]</td>
  <td><input type="text" name="new_sett[local_delivery_cost]" value="$ymlset[local_delivery_cost]" size="38" maxlength="50"></td>
 </tr>
HTMLDATA;
*/




$def_class = $admin_lib->sett_class();
$delivery_options = unpack_options(custom::get_txtsettings('yml_delivery_options'));
$max_delivery_options = 5;
$delivery_options_quantity = count($delivery_options);
 if($delivery_options_quantity < $max_delivery_options){
  for($i = 0; $i < $max_delivery_options; $i++){
   if(! isset($delivery_options[$i])){
    foreach($delivery_options_fields as $field_name){
    $delivery_options[$i][$field_name] = '';
    }
   }
  }
 }
$delivery_options_help = custom::contextHelp($lang['delivery_options_help']);
$cost_help = custom::contextHelp($lang['cost_help']);
$days_help = custom::contextHelp($lang['days_help']);
$order_before_help = custom::contextHelp($lang['order_before_help']);
$delivery_options_template = <<<HTMLDATA
<input type="text" name="delivery_options[0][cost]" value="{$delivery_options[0]['cost']}" size="10"> cost $cost_help<br>
<input type="text" name="delivery_options[0][days]" value="{$delivery_options[0]['days']}" size="10"> days $days_help<br>
<input type="text" name="delivery_options[0][order-before]" value="{$delivery_options[0]['order-before']}" size="10"> order-before $order_before_help
HTMLDATA;
$added_delivery_options = '';
 for($i = 1; $i < $delivery_options_quantity; $i++){
 $added_delivery_options .= <<<HTMLDATA
 <hr>
 <input type="text" name="delivery_options[$i][cost]" value="{$delivery_options[$i]['cost']}" size="10"> cost<br>
 <input type="text" name="delivery_options[$i][days]" value="{$delivery_options[$i]['days']}" size="10"> days<br>
 <input type="text" name="delivery_options[$i][order-before]" value="{$delivery_options[$i]['order-before']}" size="10"> order-before
HTMLDATA;
 }
$ret .= <<<HTMLDATA
 <tr class="$def_class">
  <td style="vertical-align:top;">$lang[delivery_options] $delivery_options_help<br><a href="javascript:addDeliveryOption();">$lang[add_options]</a></td>
  <td>
   <div id="delivery_options_template">
   $delivery_options_template
   </div>
   <div id="added_delivery_options">
   $added_delivery_options
   </div>
<script type="text/javascript">
var max_delivery_options=$max_delivery_options;
var quantityDeliveryOptions=$delivery_options_quantity;
 if(quantityDeliveryOptions==0){
 quantityDeliveryOptions=1;
 }
function addDeliveryOption(){
 if(quantityDeliveryOptions>=max_delivery_options){
 alert('Limit: '+quantityDeliveryOptions);
 return;
 }
var optTpl=document.getElementById('delivery_options_template').innerHTML.replace(/delivery_options\[0\]/g, 'delivery_options['+quantityDeliveryOptions+']')
optTpl=optTpl.replace(/value\=\"[^\"]+\"/g, 'value=""');
document.getElementById('added_delivery_options').innerHTML+='<hr>'+optTpl;
quantityDeliveryOptions++;
}
</script>
  </td>
 </tr>
HTMLDATA;




$def_class = $admin_lib->sett_class();
$save_help = custom::contextHelp($lang['products_add_par_save_help']);
 if(! isset($ymlset['sales_notes'])){
 $ymlset['sales_notes'] = '';
 }
$ret .= <<<HTMLDATA
 <tr class="$def_class">
  <td>$lang[sales_notes]</td>
  <td><input type="text" name="new_sett[sales_notes]" value="$ymlset[sales_notes]" size="38" maxlength="50"></td>
 </tr>
 
</table><br>

<input type="submit" value="$lang[submit]" class="button1"> $save_help
</form>
</body></html>
HTMLDATA;

return $ret;
}


function get_sett_checked($name){
global $ymlset;
$schecked = array();
 if(! empty($ymlset[$name])){
 $schecked['true']=' checked="checked"';
 $schecked['false']='';
 $schecked['not_use']='';
 }
 elseif(isset($ymlset[$name]) && $ymlset[$name] == 0 && is_numeric($ymlset[$name])){
 $schecked['true']='';
 $schecked['false']=' checked="checked"';
 $schecked['not_use']='';
 }
 else{
 $schecked['true']='';
 $schecked['false']='';
 $schecked['not_use']=' checked="checked"';
 }
return $schecked;
}


function get_true_false_str($name){
global $ymlset;
 if(! empty($ymlset[$name])){
 return 'true';
 }
 elseif(isset($ymlset[$name]) && $ymlset[$name] == 0 && is_numeric($ymlset[$name])){
 return 'false';
 }
 else{
 return '';
 }
}


function save_products_add_par(){
global $lang, $admin_lib, $custom, $ymlset, $db;
if(! $admin_lib->check_admin_perms()){return $admin_lib->nosave_perms_msg();}
$admin_lib->save_txtsettings(array('yml_delivery_options' => pack_options($_POST['delivery_options'])));
$res = $admin_lib->save_settings(5, $_POST['new_sett']);
$ymlset = $custom->get_settings(5);
return $res;
}


function yml_currencies_list($selected_curr_id){
global $db, $lang;
$ret = '';
$tbl = DB_PREFIX.'currencies';
$res = $db->query("SELECT currency_id, title, iso_alpha FROM $tbl WHERE enabled = 1") or die($db->error());
 while($row=$db->fetch_array($res)){

  if($row['currency_id'] == $selected_curr_id){
  $selected=' selected="selected"';
  }
  else{
  $selected='';
  }

  if(empty($row['iso_alpha'])){
  $row['iso_alpha'] = "$lang[empty_value] ISO 3166 alpha";
  $style = ' style="background-color:#F7E8E6;"';
  }
  else{
  $style='';
  }

 $ret.="<option value=\"$row[currency_id]\"$selected$style>$row[title] ($row[iso_alpha])</option>";
 }
return $ret;
}


//возвращает ключ элемента $str в массиве; если элемент $str отсутствует, возвращает -1
//используя Интерполяционный поиск в сортированном массиве
//массив ОБЯЗАТЕЛЬНО должен быть отсортирован методом СТРОКОВОЙ сортировки
//сортировать с параметром SORT_STRING sort($array, SORT_STRING), иначе будут ошибки из-за цифр
//Для массивов большого размера функцию также можно использовать вместо in_array
//в сортированном массиве методом СТРОКОВОЙ сортировки
//В больших массивах работает быстрее чем in_array
function yml_get_arr_key($str, &$arr, $arr_size){
//$arr_size=sizeof($arr); здесь sizeof не используем, для повышения быстродействия передаём впеременной
 if($arr_size < 1){
 return -1;
 }
 elseif($arr_size == 1){
  if(strcmp($str, $arr[0]) == 0){
  //возвращаем искомый ключ
  return 0;
  }
  else{
  return -1;
  }
 }
$a = 0;
$z = $arr_size;
$defindex = ceil(($z + 0.0) / 2);
$cmp = 0;
 while($defindex != $z){
 $cmp = strcmp($str, $arr[$defindex]);
  if($cmp > 0){
  $a = $defindex;
  $defindex = ceil((($z-$defindex + 0.0) / 2) + $defindex);
  }
  elseif($cmp < 0){
   if($defindex == 1){
	  if(strcmp($str, $arr[0]) == 0){
	  //возвращаем искомый ключ
	  return 0;
	  }
	  else{
	  return -1;
	  }
   }
  $z = $defindex;
  $defindex = ceil((($defindex - $a + 0.0)/2) + $a);
  }
  //if $cmp==0
  else{
  //возвращаем искомый ключ
  return $defindex;
  }
 }
return -1;
}


function ym_get_all_manufacturers(){
global $db;
$manufacturers = array();
$tbl = DB_PREFIX.'manufacturers';
$res = $db->query("SELECT `mnf_id`, `title` FROM `$tbl` WHERE `mnf_id` <> 0") or die($db->error());
 while($row=$db->fetch_array($res)){
 $manufacturers[$row['mnf_id']]['title'] = $row['title'];
 }
return $manufacturers;
}


function load_mod_language(){
global $sett, $lang, $mod;
$default_language = preg_replace("([^a-zA-Z0-9\_\-])", '', $sett['lang']);
 if(! file_exists(MODULES_DIR."/$mod/admin/$default_language".'.lng')){
 $default_language = 'rus';
 echo "Invalid language!";
 return false;
 }
$fh = fopen(MODULES_DIR."/$mod/admin/$default_language".'.lng', "r") or die('Can\'t load language file!');
 while(! feof($fh)){
 $language_str = explode('=', fgets($fh, 2048), 2);
 $language_str[0] = trim($language_str[0]);
  if($language_str[0]){
  $lang[$language_str[0]] = trim($language_str[1]);
  }
 }
fclose($fh);
return true;
}


//запаковывает вложенные настройки для хранения в базе
//cost=0,days=1-2,order-before=12,;cost=100,days=2-3,order-before=15,;
function pack_options($arr){
$str = '';
 foreach($arr as $index => $arr2){
 $sub = '';
 $count = count($arr2);
 $cnt = 0;
  if($count > 0){
   foreach($arr2 as $name => $value){
   $name = preg_replace('/\;\,\=/', ' ', $name);
   $name = trim($name);
   $value = trim($value);
    if($name !== ''){
    $sub .= "$name=$value,";
    }
    if($value !== ''){
    $cnt++;
    }
   }
  }
  //$cnt > 0 - значит что-то заполнено из cost days order-before
  if($sub !== '' && $cnt > 0){
  $str .= $sub . ';';
  }
 }
return $str;
}


//распаковывает вложенные настройки из базы в массив
//cost=0,days=1-2,order-before=12,;cost=100,days=2-3,order-before=15,;
function unpack_options($str){
$options = array();
$level1 = explode(';', $str);
 for($i = 0; $i < count($level1); $i++){
 $level2 = explode(',', $level1[$i]);
  foreach($level2 as $str2){
  $level3 = explode('=', $str2);
   if($level3[0] !== ''){
   $options[$i][$level3[0]] = $level3[1];
   }
  }
 }
return $options;
}

?>