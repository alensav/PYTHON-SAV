<?php
// Copyright (c) Igor Anikeev http://www.arwshop.ru/

if(! defined('SYS_LOADER')){die();}
global $mod;
$yml_file = 'yandex_market.xml';

$act = '';
$file_type = '';

 if($_SERVER['REQUEST_METHOD'] == 'GET'){
 $act = isset($_GET['act']) ? $_GET['act'] : '';
 $file_type = isset($_GET['file_type']) ? $_GET['file_type'] : '';
 }
 elseif($_SERVER['REQUEST_METHOD'] == 'POST'){
 $act = isset($_POST['act']) ? $_POST['act'] : '';
 $file_type = isset($_POST['file_type']) ? $_POST['file_type'] : '';
 }

 if($act == 'select_file_type' || ($act === '' && empty($_GET['download']) && empty($_POST['download']) ) ){
 echo <<<HTMLDATA
<h1>Select content-Type:</h1>
<p><a href="?mod=$mod&amp;download=1&amp;independ=1&amp;file_type=text_plain">text/plain</a></p>
<p><a href="?mod=$mod&amp;download=1&amp;independ=1&amp;file_type=text_xml">text/xml</a></p>
<p><a href="?mod=$mod&amp;download=1&amp;independ=1&amp;file_type=text_xml_attachment">text/xml attachment</a></p>
HTMLDATA;
 }
 elseif(empty($_GET['independ']) && empty($_POST['independ'])){
 echo 'Use parameter &amp;independ=1';
 }
 elseif( (! empty($_GET['download']) || ! empty($_POST['download']) ) && file_exists(SCRIPTCHF_DIR."/adm/dump/$yml_file")){

 header("Pragma: no-cache");
 header("Cache-Control: no-cache, must-revalidate");
 header("Expires: " . gmdate("D, d M Y H:i:s", filemtime(SCRIPTCHF_DIR."/adm/dump/$yml_file")) . " GMT");

  switch($file_type){

  case 'text_plain':
  header("Content-Type: text/plain");
  break;

  case 'text_xml':
  header("Content-Type: text/xml");
  break;

  case 'text_xml_attachment':
  header("Content-Type: application/force-download; name=\"$yml_file\"");
  header("Content-disposition: attachment; filename=$yml_file");
  header("Accept-Ranges: bytes");
  header("Content-length: " . filesize(SCRIPTCHF_DIR."/adm/dump/$yml_file"));
  break;

  default: header("Content-Type: text/xml");

  }

 $fh = fopen(SCRIPTCHF_DIR."/adm/dump/$yml_file","rb");
 if(! $fh){die('Cannot open file '.SCRIPTCHF_DIR."/adm/dump/$yml_file");}
  while(! @feof($fh)){
  echo @fread($fh, 65536);
  }
 @fclose($fh);


 }
 elseif(! file_exists(SCRIPTCHF_DIR."/adm/dump/$yml_file")){
 header404();
 echo "YML file not found";
 }
 else{
 header404();
 echo "Invalid parameters!";
 }

?>