<?php
 // Если файл загружен не из движка - завершаем программу
 if(! defined('SYS_LOADER')){
 die();
 }
?>
<h1>Удаление товаров по ID</h1>
<?php

 if(! empty($_POST['products_id'])){
 require_once(INC_DIR."/admin/ed_cat.php");
 global $ed_category;
 $ed_category = new ed_category;
 require_once(INC_DIR."/admin/items.php");
 $items = new items;
 $arr = explode(',', $_POST['products_id']);
  foreach($arr as $itemid){
  $itemid = intval(trim($itemid));
   if($itemid){
   $items->delete_item($itemid);
   }
  }
 $ed_category->update_totalitemcount(0);
 echo '<p>Выполнено</p>';
 }

?>
<form name="sample_form" action="?" method="POST">
<input type="hidden" name="mod" value="delete_products_by_id">
<input type="hidden" name="independ" value="<?php if(! empty($_GET['independ']) || ! empty($_POST['independ'])){echo '1';} ?>">
ID товаров для удаления через запятую, например: 55, 87, 132<br>
<textarea name="products_id" cols="40" rows="5"></textarea><br>
Удаление изображений производится в соответствии с опцией <a href="?view=settings&settype=adminconfig">&quot;Удалять изображения товара при загрузке новых изображений товара или удалении товара&quot;</a>
<input type="submit" value="Удалить товары">
</form>
